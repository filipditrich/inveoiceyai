INVOICEY BRAND KIT · 2026

Invoicey is Czech-first invoice automation with a dark-first graphite identity
and one precise orange signal.

Use the full wordmark on branded horizontal surfaces. Its orange dot replaces
the dot above the second i in Invoicey; never add another dot.

Use the I monogram for favicons, app icons, menu bars, collapsed navigation,
OAuth applications, Slack, and other square or compact placements.

Core colors
  Graphite     #0B0B0C
  Panel        #151517
  Signal orange #F97316
  Warm white   #F5F5F4
  Quiet gray   #A1A1AA

Provider-ready files are named for their intended destination. Consult the PDF
guidelines and https://invoicey.ditrich.me/brand before publishing changes.

Copyright Invoicey. Provided for authorized Invoicey product and partner use.
